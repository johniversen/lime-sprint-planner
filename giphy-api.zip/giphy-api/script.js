var $form = $("form");
var $search = $(".search");
var $giphy = $(".giphy img");
var $giphyLink = $(".giphy a");

// launch function on form submit
$form.on("submit", function(e) {
  e.preventDefault();
  goGiphy();
});

function goGiphy() {
  var input = $search.val();
  // Ajax call to giphy API  
  $.getJSON("https://api.giphy.com/v1/gifs/translate?api_key=bb2006d9d3454578be1a99cfad65913d&s=" + input, function(json) {
    data = JSON.parse(JSON.stringify(json));
    imgSrc = data.data.images.original.url;
    setTimeout( function() {
      $giphy.attr("src", imgSrc);
      $giphyLink.attr("href", imgSrc);
      setTimeout( function() {
        $giphy.addClass("gif");
      }, 100);
    }, 100);
  })
}